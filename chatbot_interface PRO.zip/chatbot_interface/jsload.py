import json

# Charger le fichier JSON
with open("data.json", "r", encoding="utf-8") as f:
    data = json.load(f)
# Extraire les textes et les métadonnées
texts = [entry["text"] for entry in data]
metadata = [entry["metadata"] for entry in data]

import pickle

# Sauvegarder les textes et métadonnées dans des fichiers .pkl
with open("texts.pkl", "wb") as f:
    pickle.dump(texts, f)

with open("metadata.pkl", "wb") as f:
    pickle.dump(metadata, f)
