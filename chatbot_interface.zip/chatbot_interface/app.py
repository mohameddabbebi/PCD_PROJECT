from flask import Flask, render_template, request, jsonify
import faiss
from sentence_transformers import SentenceTransformer
import numpy as np
import json


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get("message")
    # Pour l'instant, on répond avec un message statique
    respons = retrieve_relevant_texts(user_input,k=2)
    response = f"Chatbot : {user_input}"
    return jsonify({"response": respons})

if __name__ == '__main__':
    app.run(debug=True)
